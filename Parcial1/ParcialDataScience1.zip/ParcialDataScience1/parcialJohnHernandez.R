#PARCIAL CIENCIA DE LOS DATOS--- JOHN HERNANDEZ
library(dplyr)
#1. Read the dataset airport.csv in R and call it airx

airx<-read.csv("airport.csv",header = TRUE)
?read.csv

#2. Cuantas filas y columnas tiene el dataset airx?
ncol(airx) #numero de columnas
nrow(airx)#numero de filas
#  3. Cual es el tiempo promedio en horas de los vuelos con destino a Denver
#(DEN) por aerolinea.
tail(airx)
colnames(airx)

subset(airx,Dest=='DEN')%>%group_by(UniqueCarrier)%>%summarise(
  tiempoPromedioADenver=mean(ActualElapsedTime,na.rm = TRUE)/60
)

#4. Cual es la aerolinea con el mayor tiempo promedio de "ArrDelay"?


airx%>%group_by(UniqueCarrier)%>%summarise(
  averageArrDelay=mean(ArrDelay,na.rm = TRUE)
)%>%filter(averageArrDelay==max(averageArrDelay))

#  5. Cu�ntos vuelos est�n demorados en la salida (DepDelay) por m�s de una
#hora?
sum(airx$DepDelay>60,na.rm = TRUE)


#  6. Cu�ntos vuelos tuvieron como destino a Atlanta?
sum(airx$Dest=='ATL')

#  7. �Cu�ntos vuelos tuvieron una demora en la llegada (ArrDelay) superior al
#doble de la espera en la salida (DepDelay)?
vuelos<-airx%>%filter(ArrDelay>DepDelay*2)
nrow(vuelos)#numero de registros es decir numero de vuelos que cumplieron la condicion


#  8. Cu�ntos vuelos son cancelados debido al mal tiempo ?
sum(airx$CancellationCode=='B')

#  9. Crear una nueva variable donde se calcule la velocidad de los vuelos en Milas/ hora.
airx%>%mutate(
  speed=Distance/(AirTime/60)
)


#10. Realizar un gr�fico utilizando al menos 4 variables del dataset.
colnames(airx)
library(ggplot2)
airxByCarrierToDEN<-airx%>%group_by(UniqueCarrier)%>%filter(Dest=='DEN',Cancelled=1)

ggplot(airx, aes(x =Month, y=ArrTime,color=CancellationCode)) +
  geom_point()  + facet_wrap(~ UniqueCarrier)

